# 🔥 Heat Check

> Think you have the hottest idea to build an app or new business? Let us check it for you.

AI-powered startup idea validator. Get a brutal, honest revenue report in seconds —
target customer, pricing strategy, acquisition tactics, competitors, and a final verdict.

---

## Deploy in 15 Minutes

### Step 1 — Get your Anthropic API Key
1. Go to [console.anthropic.com](https://console.anthropic.com)
2. Create an account and add a payment method
3. Go to **API Keys** → **Create Key**
4. Copy the key (starts with `sk-ant-...`)

### Step 2 — Create your Stripe Payment Link
1. Go to [dashboard.stripe.com](https://dashboard.stripe.com)
2. Create a free Stripe account
3. Go to **Payment Links** → **Create payment link**
4. Set the price to **$29/month** (recurring)
5. Under **After payment**, set the redirect URL to:
   `https://YOUR-VERCEL-DOMAIN.vercel.app?payment=success`
6. Copy the payment link URL (looks like `https://buy.stripe.com/...`)

### Step 3 — Deploy to Vercel
1. Go to [vercel.com](https://vercel.com) and create a free account
2. Click **Add New Project** → **Import Git Repository**
   - Or drag-and-drop this folder into Vercel's dashboard
3. In **Environment Variables**, add:
   ```
   VITE_ANTHROPIC_API_KEY     = sk-ant-YOUR_KEY
   VITE_STRIPE_PAYMENT_LINK   = https://buy.stripe.com/YOUR_LINK
   ```
4. Click **Deploy**
5. Done. Your app is live. 🔥

### Step 4 — Update your Stripe success URL
Once Vercel gives you your live domain (e.g. `heat-check.vercel.app`):
1. Go back to your Stripe payment link settings
2. Update the success redirect to your real domain

---

## Local Development

```bash
# Install dependencies
npm install

# Copy env file and fill in your keys
cp .env.example .env.local

# Start dev server
npm run dev
```

App runs at `http://localhost:5173`

---

## How the Paywall Works

- Users get **3 free Heat Checks** (stored in localStorage)
- On the 4th attempt, the upgrade modal appears
- Stripe handles payment at $29/month
- After successful payment, Stripe redirects to `?payment=success`
- The app detects this, sets a `paid` flag in localStorage, and unlocks unlimited checks

> **Note:** For a production app, move payment verification to a server-side API
> so the paid status is verified against your Stripe customer records rather than
> relying on localStorage. This is a great first version to validate demand.

---

## Monetization Milestones

| Users | MRR |
|-------|-----|
| 10    | $290 |
| 50    | $1,450 |
| 100   | $2,900 |
| 345   | $10,005 |
| 1,000 | $29,000 |

---

## Stack

- **React 18** + **Vite** — frontend
- **Claude Sonnet** via Anthropic API — AI analysis
- **Stripe Payment Links** — monetization (no backend needed)
- **Vercel** — hosting & deployment

---

## Next Steps to Grow

1. **Add email capture** before the free checks run out (Mailchimp / Beehiiv)
2. **Post to Product Hunt** targeting the AI/founder communities
3. **Share in the communities** of creators like Greg Isenberg, McKay Wrigley, Riley Brown
4. **Add team plans** at $99/mo for unlimited seats
5. **Build a report history** page (requires auth — Clerk or Supabase)
