import React from 'react'

const STRIPE_PAYMENT_LINK = import.meta.env.VITE_STRIPE_PAYMENT_LINK || 'https://buy.stripe.com/YOUR_PAYMENT_LINK'

export default function PaywallModal({ onDismiss }) {
  function handleUpgrade() {
    // Stripe payment link with success redirect back to app
    const successUrl = encodeURIComponent(window.location.origin + '?payment=success')
    window.location.href = `${STRIPE_PAYMENT_LINK}?success_url=${successUrl}`
  }

  return (
    <div style={{
      position: 'fixed',
      inset: 0,
      background: 'rgba(0,0,0,0.85)',
      backdropFilter: 'blur(8px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000,
      padding: '20px',
      animation: 'fadeIn 0.25s ease'
    }}>
      <style>{`
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(24px); } to { opacity: 1; transform: translateY(0); } }
        .upgrade-btn {
          width: 100%;
          background: #ff6b35;
          color: #0a0a0a;
          border: none;
          padding: 16px 36px;
          font-family: 'Space Mono', monospace;
          font-weight: 700;
          font-size: 14px;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          cursor: pointer;
          transition: all 0.2s;
          margin-bottom: 12px;
        }
        .upgrade-btn:hover { background: #ff8c5a; transform: translateY(-1px); box-shadow: 0 4px 28px #ff6b3566; }
        .dismiss-btn {
          background: transparent;
          border: none;
          color: #555;
          font-family: 'Space Mono', monospace;
          font-size: 12px;
          cursor: pointer;
          letter-spacing: 0.08em;
          padding: 8px;
          width: 100%;
          transition: color 0.2s;
        }
        .dismiss-btn:hover { color: #888; }
      `}</style>

      <div style={{
        background: '#111',
        border: '1px solid #ff6b3533',
        boxShadow: '0 0 80px #ff6b3520, 0 24px 64px rgba(0,0,0,0.8)',
        maxWidth: '460px',
        width: '100%',
        padding: '48px 40px',
        animation: 'slideUp 0.3s ease',
        textAlign: 'center'
      }}>
        {/* Flame icon */}
        <div style={{ fontSize: '52px', marginBottom: '24px', lineHeight: 1 }}>🔥</div>

        <div style={{
          fontFamily: "'Space Mono', monospace",
          fontSize: '10px',
          color: '#ff6b35',
          letterSpacing: '0.25em',
          textTransform: 'uppercase',
          marginBottom: '16px'
        }}>You've Used Your Free Checks</div>

        <h2 style={{
          fontFamily: "'Bebas Neue', sans-serif",
          fontSize: '42px',
          color: '#fff',
          letterSpacing: '0.04em',
          lineHeight: 0.95,
          marginBottom: '20px'
        }}>
          KEEP THE<br />
          <span style={{ color: '#ff6b35' }}>HEAT ON</span>
        </h2>

        <p style={{
          fontFamily: "'Lora', serif",
          fontStyle: 'italic',
          color: '#777',
          fontSize: '15px',
          lineHeight: '1.65',
          marginBottom: '36px'
        }}>
          Unlimited Heat Checks, full revenue reports, and brutally honest AI analysis — for less than a coffee a day.
        </p>

        {/* Pricing */}
        <div style={{
          background: '#0a0a0a',
          border: '1px solid #ff6b3522',
          padding: '24px',
          marginBottom: '28px'
        }}>
          <div style={{
            fontFamily: "'Bebas Neue', sans-serif",
            fontSize: '56px',
            color: '#ff6b35',
            letterSpacing: '0.02em',
            lineHeight: 1
          }}>$29</div>
          <div style={{
            fontFamily: "'Space Mono', monospace",
            fontSize: '11px',
            color: '#555',
            letterSpacing: '0.15em',
            textTransform: 'uppercase',
            marginTop: '4px'
          }}>Per Month · Cancel Anytime</div>

          <div style={{ marginTop: '20px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {[
              '✓ Unlimited idea checks',
              '✓ Full revenue & competitor reports',
              '✓ Pricing & acquisition strategy',
              '✓ Brutal AI-powered honesty',
            ].map(item => (
              <div key={item} style={{
                fontFamily: "'Space Mono', monospace",
                fontSize: '12px',
                color: '#aaa',
                letterSpacing: '0.04em',
                textAlign: 'left'
              }}>{item}</div>
            ))}
          </div>
        </div>

        <button className="upgrade-btn" onClick={handleUpgrade}>
          Unlock Unlimited Checks →
        </button>
        <button className="dismiss-btn" onClick={onDismiss}>
          No thanks, I'm out of ideas
        </button>
      </div>
    </div>
  )
}
