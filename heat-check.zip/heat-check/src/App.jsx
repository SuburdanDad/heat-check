import HeatCheck from './HeatCheck'

export default function App() {
  return <HeatCheck />
}
