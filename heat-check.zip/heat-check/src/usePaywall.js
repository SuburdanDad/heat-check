import { useState, useEffect } from 'react'

const FREE_LIMIT = 3
const STORAGE_KEY = 'hc_checks_used'
const PAID_KEY = 'hc_paid'

export function usePaywall() {
  const [checksUsed, setChecksUsed] = useState(0)
  const [isPaid, setIsPaid] = useState(false)
  const [showPaywall, setShowPaywall] = useState(false)

  useEffect(() => {
    const used = parseInt(localStorage.getItem(STORAGE_KEY) || '0', 10)
    const paid = localStorage.getItem(PAID_KEY) === 'true'
    setChecksUsed(used)
    setIsPaid(paid)
  }, [])

  // Call this after a successful Stripe checkout redirect
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    if (params.get('payment') === 'success') {
      localStorage.setItem(PAID_KEY, 'true')
      setIsPaid(true)
      // Clean URL
      window.history.replaceState({}, '', window.location.pathname)
    }
  }, [])

  function incrementChecks() {
    const next = checksUsed + 1
    setChecksUsed(next)
    localStorage.setItem(STORAGE_KEY, String(next))
  }

  function canCheck() {
    return isPaid || checksUsed < FREE_LIMIT
  }

  function checksRemaining() {
    if (isPaid) return Infinity
    return Math.max(0, FREE_LIMIT - checksUsed)
  }

  function triggerPaywall() {
    setShowPaywall(true)
  }

  function dismissPaywall() {
    setShowPaywall(false)
  }

  return {
    isPaid,
    checksUsed,
    checksRemaining: checksRemaining(),
    canCheck: canCheck(),
    showPaywall,
    triggerPaywall,
    dismissPaywall,
    incrementChecks,
    FREE_LIMIT,
  }
}
