import { useState, useEffect } from 'react'
import { usePaywall } from './usePaywall'
import PaywallModal from './PaywallModal'

const STAGES = [
  'Checking the temperature...',
  'Identifying target customers...',
  'Estimating pricing power...',
  'Scanning competitor landscape...',
  'Mapping acquisition channels...',
  'Building your heat report...',
]

function TypingText({ text }) {
  const [displayed, setDisplayed] = useState('')
  useEffect(() => {
    setDisplayed('')
    let i = 0
    const interval = setInterval(() => {
      setDisplayed(text.slice(0, i + 1))
      i++
      if (i >= text.length) clearInterval(interval)
    }, 16)
    return () => clearInterval(interval)
  }, [text])
  return <span>{displayed}</span>
}

function ScoreBar({ score, label, color }) {
  const [width, setWidth] = useState(0)
  useEffect(() => {
    const t = setTimeout(() => setWidth(score), 150)
    return () => clearTimeout(t)
  }, [score])
  return (
    <div style={{ marginBottom: '16px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
        <span style={{ fontSize: '12px', fontFamily: "'Space Mono', monospace", color: '#777', letterSpacing: '0.08em', textTransform: 'uppercase' }}>{label}</span>
        <span style={{ fontSize: '13px', fontFamily: "'Space Mono', monospace", color, fontWeight: '700' }}>{score}/100</span>
      </div>
      <div style={{ height: '5px', background: '#1a1a1a', borderRadius: '3px', overflow: 'hidden' }}>
        <div style={{
          height: '100%',
          width: `${width}%`,
          background: `linear-gradient(90deg, ${color}66, ${color})`,
          borderRadius: '3px',
          transition: 'width 1.3s cubic-bezier(0.16, 1, 0.3, 1)'
        }} />
      </div>
    </div>
  )
}

function Section({ title, children, accent }) {
  return (
    <div style={{ borderLeft: `3px solid ${accent}`, paddingLeft: '20px', marginBottom: '36px' }}>
      <div style={{
        fontSize: '10px',
        fontFamily: "'Space Mono', monospace",
        color: accent,
        letterSpacing: '0.2em',
        textTransform: 'uppercase',
        marginBottom: '12px'
      }}>{title}</div>
      <div style={{ color: '#d4d4d4', fontSize: '15px', lineHeight: '1.8', fontFamily: "'Lora', serif" }}>
        {children}
      </div>
    </div>
  )
}

function parseReport(text) {
  const sections = {}
  const patterns = {
    scores:      /SCORES:([\s\S]*?)(?=CUSTOMER:|$)/i,
    customer:    /CUSTOMER:([\s\S]*?)(?=PRICING:|$)/i,
    pricing:     /PRICING:([\s\S]*?)(?=ACQUISITION:|$)/i,
    acquisition: /ACQUISITION:([\s\S]*?)(?=COMPETITORS:|$)/i,
    competitors: /COMPETITORS:([\s\S]*?)(?=VERDICT:|$)/i,
    verdict:     /VERDICT:([\s\S]*?)$/i,
  }
  for (const [key, pattern] of Object.entries(patterns)) {
    const match = text.match(pattern)
    sections[key] = match ? match[1].trim() : ''
  }
  const scoreLines = (sections.scores || '').split('\n').filter(Boolean)
  const scores = {}
  scoreLines.forEach(line => {
    const m = line.match(/([^:]+):\s*(\d+)/)
    if (m) scores[m[1].trim()] = parseInt(m[2])
  })
  sections.parsedScores = scores
  return sections
}

const scoreColors = {
  'Market Demand':      '#ff6b35',
  'Monetization Ease':  '#facc15',
  'Execution Speed':    '#fb923c',
  'Competition Level':  '#f87171',
}

export default function HeatCheck() {
  const [idea, setIdea] = useState('')
  const [loading, setLoading] = useState(false)
  const [stageIndex, setStageIndex] = useState(0)
  const [report, setReport] = useState(null)
  const [error, setError] = useState(null)

  const paywall = usePaywall()

  useEffect(() => {
    if (!loading) return
    const interval = setInterval(() => setStageIndex(i => (i + 1) % STAGES.length), 2200)
    return () => clearInterval(interval)
  }, [loading])

  async function handleSubmit() {
    if (!idea.trim()) return

    if (!paywall.canCheck) {
      paywall.triggerPaywall()
      return
    }

    setLoading(true)
    setReport(null)
    setError(null)
    setStageIndex(0)

    const prompt = `You are a brutal, honest startup advisor used by founders who want real feedback before wasting months building something nobody wants. Analyze this app/business idea and return ONLY the structured report below — no preamble, no markdown, no asterisks. Plain text only.

IDEA: ${idea}

Return exactly in this format:

SCORES:
Market Demand: [0-100]
Monetization Ease: [0-100]
Execution Speed: [0-100]
Competition Level: [0-100]

CUSTOMER:
[2-3 sentences. Be hyper-specific — not "small businesses" but "solo freelance designers charging $75-150/hr who hate writing proposals". Include what they currently use instead.]

PRICING:
[2-3 sentences. Specific price points like "$29/mo". Explain the model and why they'd pay it.]

ACQUISITION:
[3 specific, actionable tactics to get the first 10 paying customers. Number them 1, 2, 3.]

COMPETITORS:
[2-3 real competitors that exist today. For each: name, what they do, their weakness this idea exploits.]

VERDICT:
[3-4 sentences. Direct verdict: build it or not? Biggest risk? What makes this $1M/yr vs a side project?]`

    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          messages: [{ role: 'user', content: prompt }]
        })
      })
      const data = await res.json()
      const text = data.content?.map(c => c.text || '').join('\n') || ''
      if (!text) throw new Error('Empty response')
      setReport(parseReport(text))
      paywall.incrementChecks()
    } catch (e) {
      setError('Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const checksLeft = paywall.checksRemaining
  const showChecksCounter = !paywall.isPaid

  return (
    <>
      <style>{`
        textarea:focus { outline: none; }
        textarea::placeholder { color: #3a3a3a; }
        .submit-btn {
          background: #ff6b35;
          color: #0a0a0a;
          border: none;
          padding: 15px 40px;
          font-family: 'Space Mono', monospace;
          font-weight: 700;
          font-size: 13px;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          cursor: pointer;
          transition: all 0.2s;
        }
        .submit-btn:hover:not(:disabled) {
          background: #ff8c5a;
          transform: translateY(-1px);
          box-shadow: 0 4px 28px #ff6b3555;
        }
        .submit-btn:disabled { opacity: 0.35; cursor: not-allowed; }
        .outline-btn {
          background: transparent;
          color: #ff6b35;
          border: 1px solid #ff6b3544;
          padding: 13px 36px;
          font-family: 'Space Mono', monospace;
          font-weight: 700;
          font-size: 12px;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          cursor: pointer;
          transition: all 0.2s;
        }
        .outline-btn:hover { border-color: #ff6b35; color: #ff8c5a; }
        .pulse { animation: pulse 2s ease-in-out infinite; }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.35} }
        .fade-in { animation: fadeIn 0.5s ease forwards; }
        @keyframes fadeIn { from{opacity:0;transform:translateY(14px)} to{opacity:1;transform:translateY(0)} }
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes flicker { 0%,100%{opacity:1} 48%{opacity:0.8} 50%{opacity:0.55} 52%{opacity:0.9} }
        @keyframes glow { 0%,100%{text-shadow:0 0 40px #ff6b3560} 50%{text-shadow:0 0 70px #ff6b3590,0 0 100px #ff6b3530} }
      `}</style>

      {paywall.showPaywall && <PaywallModal onDismiss={paywall.dismissPaywall} />}

      <div style={{
        minHeight: '100vh',
        background: '#0a0a0a',
        padding: '0 20px 100px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        position: 'relative'
      }}>

        {/* Ambient top glow */}
        <div style={{
          position: 'fixed', top: 0, left: '50%', transform: 'translateX(-50%)',
          width: '700px', height: '320px',
          background: 'radial-gradient(ellipse at top, #ff6b3518 0%, transparent 68%)',
          pointerEvents: 'none', zIndex: 0
        }} />

        {/* Header */}
        <div style={{
          width: '100%', maxWidth: '720px',
          paddingTop: '64px', paddingBottom: '48px',
          borderBottom: '1px solid #181818',
          position: 'relative', zIndex: 1
        }}>
          <div style={{
            fontSize: '10px',
            fontFamily: "'Space Mono', monospace",
            color: '#ff6b35',
            letterSpacing: '0.28em',
            textTransform: 'uppercase',
            marginBottom: '18px',
            animation: 'flicker 5s ease-in-out infinite'
          }}>🔥 Startup Intelligence</div>

          <h1 style={{
            fontFamily: "'Bebas Neue', sans-serif",
            fontSize: 'clamp(60px, 13vw, 100px)',
            letterSpacing: '0.04em',
            lineHeight: '0.88',
            color: '#fff',
            marginBottom: '24px'
          }}>
            HEAT<br />
            <span style={{ color: '#ff6b35', animation: 'glow 3s ease-in-out infinite' }}>CHECK</span>
          </h1>

          <p style={{
            fontFamily: "'Lora', serif",
            fontStyle: 'italic',
            color: '#666',
            fontSize: '17px',
            maxWidth: '520px',
            lineHeight: '1.65'
          }}>
            Think you have the hottest idea to build an app or new business? Let us check it for you.
          </p>

          {showChecksCounter && (
            <div style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '8px',
              marginTop: '24px',
              padding: '8px 16px',
              border: '1px solid #222',
              background: '#111'
            }}>
              <span style={{ fontSize: '16px' }}>
                {checksLeft > 0 ? '🔥'.repeat(checksLeft) : '💀'}
              </span>
              <span style={{
                fontFamily: "'Space Mono', monospace",
                fontSize: '11px',
                color: checksLeft > 0 ? '#666' : '#f87171',
                letterSpacing: '0.08em'
              }}>
                {checksLeft > 0
                  ? `${checksLeft} free check${checksLeft !== 1 ? 's' : ''} remaining`
                  : 'No free checks left — upgrade to continue'
                }
              </span>
            </div>
          )}
        </div>

        {/* Input area */}
        <div style={{ width: '100%', maxWidth: '720px', paddingTop: '40px', position: 'relative', zIndex: 1 }}>
          <div style={{
            fontSize: '11px',
            fontFamily: "'Space Mono', monospace",
            color: '#444',
            letterSpacing: '0.15em',
            textTransform: 'uppercase',
            marginBottom: '12px'
          }}>Drop your idea</div>

          <textarea
            value={idea}
            onChange={e => setIdea(e.target.value)}
            placeholder="e.g. An AI tool that writes cold emails personalized to each prospect's LinkedIn profile and recent posts, with one-click sending from Gmail..."
            rows={5}
            style={{
              width: '100%',
              background: '#0f0f0f',
              border: '1px solid #222',
              borderRadius: '2px',
              color: '#e5e5e5',
              fontFamily: "'Lora', serif",
              fontSize: '15px',
              lineHeight: '1.75',
              padding: '20px',
              resize: 'vertical',
              transition: 'border-color 0.2s',
            }}
            onFocus={e => e.target.style.borderColor = '#ff6b3566'}
            onBlur={e => e.target.style.borderColor = '#222'}
          />

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '16px' }}>
            <div style={{
              fontFamily: "'Space Mono', monospace",
              fontSize: '11px',
              color: '#333',
              letterSpacing: '0.06em'
            }}>
              {idea.length > 0 && `${idea.length} chars`}
            </div>
            <button
              className="submit-btn"
              onClick={handleSubmit}
              disabled={loading || !idea.trim()}
            >
              {loading ? 'Running...' : (paywall.canCheck ? 'Run Heat Check 🔥' : 'Upgrade to Continue →')}
            </button>
          </div>
        </div>

        {/* Loading */}
        {loading && (
          <div style={{
            width: '100%', maxWidth: '720px',
            paddingTop: '64px', textAlign: 'center', zIndex: 1
          }}>
            <div style={{
              width: '44px', height: '44px',
              border: '2px solid #1a1a1a',
              borderTop: '2px solid #ff6b35',
              borderRadius: '50%',
              animation: 'spin 0.9s linear infinite',
              margin: '0 auto 28px'
            }} />
            <div className="pulse" style={{
              fontFamily: "'Space Mono', monospace",
              fontSize: '11px',
              color: '#ff6b35',
              letterSpacing: '0.18em',
              textTransform: 'uppercase'
            }}>
              {STAGES[stageIndex]}
            </div>
          </div>
        )}

        {/* Error */}
        {error && !loading && (
          <div style={{
            width: '100%', maxWidth: '720px', marginTop: '32px', zIndex: 1,
            padding: '16px 20px',
            border: '1px solid #f8717133',
            background: '#f8717108',
            color: '#f87171',
            fontFamily: "'Space Mono', monospace",
            fontSize: '12px',
            letterSpacing: '0.04em'
          }}>{error}</div>
        )}

        {/* Report */}
        {report && !loading && (
          <div className="fade-in" style={{ width: '100%', maxWidth: '720px', paddingTop: '64px', zIndex: 1 }}>

            {/* Section divider */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '52px' }}>
              <div style={{ flex: 1, height: '1px', background: '#1a1a1a' }} />
              <div style={{
                fontSize: '10px',
                fontFamily: "'Space Mono', monospace",
                color: '#ff6b35',
                letterSpacing: '0.22em',
                textTransform: 'uppercase'
              }}>🔥 Heat Report</div>
              <div style={{ flex: 1, height: '1px', background: '#1a1a1a' }} />
            </div>

            {/* Scores */}
            {Object.keys(report.parsedScores).length > 0 && (
              <div style={{ marginBottom: '52px' }}>
                <div style={{
                  fontSize: '10px',
                  fontFamily: "'Space Mono', monospace",
                  color: '#444',
                  letterSpacing: '0.2em',
                  textTransform: 'uppercase',
                  marginBottom: '20px'
                }}>Signal Scores</div>
                {Object.entries(report.parsedScores).map(([label, score]) => (
                  <ScoreBar key={label} label={label} score={score} color={scoreColors[label] || '#ff6b35'} />
                ))}
              </div>
            )}

            {report.customer && (
              <Section title="Target Customer" accent="#ff6b35">
                <TypingText text={report.customer} />
              </Section>
            )}

            {report.pricing && (
              <Section title="Pricing Strategy" accent="#facc15">
                {report.pricing}
              </Section>
            )}

            {report.acquisition && (
              <Section title="First 10 Customers" accent="#fb923c">
                {report.acquisition}
              </Section>
            )}

            {report.competitors && (
              <Section title="Competitor Landscape" accent="#f87171">
                {report.competitors}
              </Section>
            )}

            {report.verdict && (
              <div style={{
                background: '#0f0f0f',
                border: '1px solid #ff6b3520',
                boxShadow: '0 0 60px #ff6b3512',
                padding: '32px'
              }}>
                <div style={{
                  fontSize: '10px',
                  fontFamily: "'Space Mono', monospace",
                  color: '#ff6b35',
                  letterSpacing: '0.22em',
                  textTransform: 'uppercase',
                  marginBottom: '16px'
                }}>🔥 Final Verdict</div>
                <div style={{
                  color: '#e5e5e5',
                  fontFamily: "'Lora', serif",
                  fontSize: '16px',
                  lineHeight: '1.85',
                  fontStyle: 'italic'
                }}>{report.verdict}</div>
              </div>
            )}

            {/* CTA after report */}
            <div style={{ marginTop: '48px', display: 'flex', gap: '16px', justifyContent: 'center', flexWrap: 'wrap' }}>
              <button
                className="outline-btn"
                onClick={() => {
                  setReport(null)
                  setIdea('')
                  window.scrollTo({ top: 0, behavior: 'smooth' })
                }}
              >
                ← Check Another Idea
              </button>

              {!paywall.isPaid && checksLeft === 0 && (
                <button className="submit-btn" onClick={paywall.triggerPaywall}>
                  Unlock Unlimited 🔥
                </button>
              )}
            </div>
          </div>
        )}

        {/* Footer */}
        <div style={{
          marginTop: '80px',
          paddingTop: '24px',
          borderTop: '1px solid #141414',
          width: '100%', maxWidth: '720px',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          position: 'relative', zIndex: 1
        }}>
          <span style={{ fontFamily: "'Space Mono', monospace", fontSize: '11px', color: '#2a2a2a' }}>
            HEAT CHECK v1.0
          </span>
          <span style={{ fontFamily: "'Space Mono', monospace", fontSize: '11px', color: '#2a2a2a' }}>
            Powered by Claude AI
          </span>
        </div>
      </div>
    </>
  )
}
